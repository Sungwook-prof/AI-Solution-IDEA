import sys
import os
import tello
import cv2
import datetime
import traceback

from ObjectClassifier import ObjectClassifier

from PyQt5.QtCore import Qt, QFile, QIODevice, QXmlStreamWriter, QTextStream, QSize, QTimer
from PyQt5.QtGui import QIcon, QKeySequence, QColor, QPixmap, QFont, QImage
from PyQt5.QtWidgets import QApplication, QTextEdit, QStatusBar, QButtonGroup, QRadioButton, QToolButton, \
    QCalendarWidget, QSizePolicy, QMenu, QAction, QComboBox, QLineEdit, QCheckBox, QWidget, QGroupBox, QLabel, \
    QVBoxLayout, QHBoxLayout, QGridLayout, QLCDNumber, QDialog, QFrame

from PySARibbon.SAWidgets import SARibbonMenu, SARibbonPannelItem
from PySARibbon.SACustomize import SARibbonActionsManager, SARibbonCustomizeWidget, SARibbonCustomizeDialog
from PySARibbon import SARibbonMainWindow, SARibbonBar, SARibbonCategory, SARibbonPannel, \
    SARibbonGallery, SARibbonButtonGroupWidget
    
class MainWindow(SARibbonMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.logBuffer = []
        self.logWriteTimer = QTimer()
        self.logWriteTimer.timeout.connect(self.timeHandler)
        self.logWriteTimer.start(10)
        
        self.m_contextCategory = None
        self.m_contextCategory2 = None
        #self.m_edit = QTextEdit(self)
        self.m_customizeWidget = None
        self.m_actMgr = None
        self.m_actionTagText = 0
        self.m_actionTagWithIcon = 0
        self.loadCustomizeXmlHascall = False
        self.m_ip = ''
        self.m_step = ''
        self.m_ipEdit = QLineEdit()
        self.m_stepEdit = QLineEdit()
        
        self.CLASSIFICATION_FRAME_RECT_PERCENT = 10
        self.CLASSIFICATION_CONF = 90.0
        self.CLASSIFICATION_FRAME = 3
        self.latestDetectedLabel = ''
        self.prevFrameLabelIdx = -1
        self.sameDetectionFrameCount = 0
        self.picDateTime = [None]*8
        self.timerStartTime = None
        self.logBuffer = []
        self.stateDict = {
            "pitch": "0",
            "roll": "0",
            "yaw": "0",
            "vgx": "0",
            "vgy": "0",
            "vgz": "0",
            "templ": "0",
            "temph": "0",
            "tof": "0",
            "h": "0",
            "bat": "0",
            "baro": "0.0",
            "time": "0",
            "agx": '0.0',
            "agy": '0.0',
            "agz": '0.0',
            "wifi": '99'
        }
        
        # main layout
        self.mainView = QFrame(self)
        self.mainLayout = QHBoxLayout(self.mainView)
        self.mainLayout.setObjectName("mainLayout")
        
        # Video vide
        self.himg = QVBoxLayout()
        self.himg.setObjectName("videoLayout")
        self.video = QLabel(self)
        self.video.setMinimumSize(QSize(600, 450))
        self.video.setMaximumSize(QSize(600, 450))
        self.video.setText("")
        self.video.setPixmap(QPixmap("./res/logo.png"))
        self.video.setObjectName("video")
        self.himg.addWidget(self.video)
        
        # Time
        self.mtime = QLCDNumber(self)
        self.mtime.setDigitCount(7)
        self.mtime.setSegmentStyle(2)
        self.mtime.setProperty("value", 0.00)
        self.mtime.display('0.00')
        self.mtime.setObjectName("mainTime")
        self.mtime.setMinimumSize(QSize(600, 200))
        self.mtime.setMaximumSize(QSize(600, 200))
        self.himg.addWidget(self.mtime)
        
        self.loglist = QTextEdit(self)
        self.loglist.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.loglist.setObjectName("loglist")
        self.loglist.setMinimumSize(QSize(600, 200))
        self.loglist.setMaximumSize(QSize(600, 200))
        self.himg.addWidget(self.loglist)
        
        self.mainLayout.addLayout(self.himg)
        
        # record Layout
        self.hrecord = QVBoxLayout()
        self.hrecord.setObjectName("recordLayout")
        # image
        self.pics = []
        # inference time
        self.picTimes = []
        # inference probablilty
        self.picProbs = []
        self.probs = [0.0]*8
        self.txtLabels = ['aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car', 'cat']
        
        gridLayout = QGridLayout()
        gridLayout.setObjectName("gridLayout")
        
        font = QFont()
        font.setPointSize(25)
        font2 = QFont()
        font2.setPointSize(18)
        font.setBold(True)
        
        self.hrecord.addLayout(gridLayout)
        self.mainLayout.addLayout(self.hrecord)
        
        # Title        
        hLayout = QHBoxLayout()
        picLabel = QLabel()
        picLabel.setText('번호')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('titleNo')
        hLayout.addWidget(picLabel)
       
        picLabel = QLabel()
        picLabel.setText('라벨')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('titleLabel')
        hLayout.addWidget(picLabel)
       
        picLabel = QLabel()
        picLabel.setText('인식 이미지')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('titleImage')
        hLayout.addWidget(picLabel)
       
        picLabel = QLabel()
        picLabel.setText('인식 시간')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('titleTime')
        hLayout.addWidget(picLabel)

        picLabel = QLabel()
        picLabel.setText('인식율')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('titleRate')
        hLayout.addWidget(picLabel)
        
        gridLayout.addLayout(hLayout, 0, 0, 1, 1)
    
        font.setBold(False)
        for i in range(8):
            hLayout = QHBoxLayout()

            picLabel = QLabel(self)
            picLabel.setText(str(i+1))
            picLabel.setFont(font)
            picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            picLabel.setStyleSheet("border: 1px solid gray;")
            picLabel.setObjectName(str(i+1)+'_lbl')
            
            hLayout.addWidget(picLabel)

            picLabel = QLabel(self)
            picLabel.setText(self.txtLabels[i])
            picLabel.setFont(font)
            picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            picLabel.setStyleSheet("border: 1px solid gray;")
            picLabel.setObjectName(self.txtLabels[i]+'_lbl')
            hLayout.addWidget(picLabel)
            
            pic = QLabel(self)
            pic.setText("")
            pic.setPixmap(QPixmap("/res/noimg.jpg"))
            pic.setObjectName(self.txtLabels[i]+'_pic`')
            picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            picLabel.setStyleSheet("border: 1px solid gray;")
            self.pics.append(pic)
            hLayout.addWidget(pic, alignment=Qt.AlignCenter)
            
            picLabel = QLabel(self)
            picLabel.setText('0.00 sec.')
            picLabel.setFont(font2)
            picLabel.setObjectName(self.txtLabels[i]+'_time')
            picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            picLabel.setStyleSheet("border: 1px solid gray;")
            self.picTimes.append(picLabel)
            hLayout.addWidget(picLabel)
            
            picLabel = QLabel(self)
            picLabel.setText('0.00 %')
            picLabel.setFont(font2)
            picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            picLabel.setStyleSheet("border: 1px solid gray;")
            picLabel.setObjectName(self.txtLabels[i]+'_rate')
            self.picProbs.append(picLabel)
            hLayout.addWidget(picLabel)
            
            gridLayout.addLayout(hLayout, i+1, 0, 1, 1)
            
        font.setBold(True)

        hLayout = QHBoxLayout()
        picLabel = QLabel()
        picLabel.setText(' ')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter)
        hLayout.addWidget(picLabel)

        picLabel = QLabel()
        picLabel.setText('전체 시간')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('totalTimeLabel')
        hLayout.addWidget(picLabel)
       
        self.totalTime = QLabel()
        self.totalTime.setText('0.00 sec.')
        self.totalTime.setFont(font2)
        self.totalTime.setObjectName('totalTime')
        self.totalTime.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.totalTime.setStyleSheet("border: 3px solid gray;")
        hLayout.addWidget(self.totalTime)

        picLabel = QLabel()
        picLabel.setText('평균 인식율')
        picLabel.setFont(font)
        picLabel.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        picLabel.setStyleSheet("border: 3px solid gray;")
        picLabel.setObjectName('avgRateLabel')
        hLayout.addWidget(picLabel)
       
        self.avgRate = QLabel()
        self.avgRate.setText('0.00 %')
        self.avgRate.setFont(font2)
        self.avgRate.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.avgRate.setStyleSheet("border: 3px solid gray;")
        self.avgRate.setObjectName('avgRate')
        hLayout.addWidget(self.avgRate)

        gridLayout.addLayout(hLayout, 10, 0, 1, 1)
           
        self.initWidgets()
        
        self.tello = tello.Tello(self.log, self.stateReceive)
        self.onIPChanged()
        self.resetDetectionInfo()
        
        self.originFrame = None
        self.inferFrame = None
        
        self.objDetector = ObjectClassifier('GPU', self.getInferFrame)
    
    def getInferFrame(self):
        return self.inferFrame
    
    def stateReceive(self, stateData):
        stateData = stateData.decode('utf-8')
        states = stateData.split(';')[:-1]
        for state in states:
            keyValue = state.split(':')
            key = keyValue[0]
            value = keyValue[1]
            self.stateDict[key] = value
        #self.updateState()
        return self.stateDict

    def initWidgets(self):
        #helper = self.m_framelessHelper
        #helper.setRubberBandOnResize(False)
        self.setWindowTitle('AI PC Drone Hackathon')
        #self.mainView.show()
        self.setCentralWidget(self.mainView)
        self.setStatusBar(QStatusBar())

        ribbon = self.ribbonBar()
        ribbon.setTitle('File')
        print(__file__, '[Drone Hackathon]', 'starts.')

        # 카테고리  1
        categoryControl = ribbon.addCategoryPage('Control')
        self.createCategoryControl(categoryControl)
        
        # 카테고리 2
        categorySetting = SARibbonCategory()
        categorySetting.setCategoryName('Setting')
        categorySetting.setObjectName('categorySetting')
        ribbon.addCategoryPage(categorySetting)
        self.createCategorySetting(categorySetting)

        self.setMinimumWidth(500)
        self.showMaximized()
        self.setWindowIcon(QIcon('res/icon/nump.png'))
        
    def log(self, logStr):
        logStr = logStr.strip()
        self.logBuffer.append(logStr)    
    
    def timeHandler(self):
        self.updateImage()
        for logStr in self.logBuffer:
            self.loglist.append(logStr)
        if len(self.logBuffer) > 0:
            self.loglist.verticalScrollBar().setValue(self.loglist.verticalScrollBar().maximum())
        self.logBuffer.clear()
        #self.updateState()
        
    def resetDetectionInfo(self):
        for i in range(8):
            self.pics[i].setPixmap(QPixmap("./res/noimg.jpg"))
            self.picTimes[i].setText("0.00 sec.")
            self.picProbs[i].setText("0.00 %")
            self.picDateTime[i] = None
            self.probs[i] = 0.0
        self.runTimer = None
        self.timerStartTime = None   
        self.latestDetectedLabel = ''
        self.mtime.display('0.00')
        os.system('del /f .\result\*.jpg')

    # Get origin image info
    def getCapW(self):
        if self.tello.cap is not None:
            return self.tello.cap.get(3)
        return -1
    
    def getCapH(self):
        if self.tello.cap is not None:
            return self.tello.cap.get(4)
        return -1
    
    def getInferFrame(self):
        return self.inferFrame
    
    def updateImage(self):
        renderingW = 600
        renderingH = 450
        
        picRenderW = 100
        picRenderH = 100
        
        try:
            if self.tello.cap is not None:
                w = self.getCapW()
                h = self.getCapH()
                cutW = w*self.CLASSIFICATION_FRAME_RECT_PERCENT/100
                cutH = h*self.CLASSIFICATION_FRAME_RECT_PERCENT/100
                cut_rect = (int(cutW), int(cutH), int(w-cutW), int(h-cutH))
                self.originFrame = self.tello.readFrame()
                if self.originFrame is not None:
                    self.inferFrame = self.originFrame[cut_rect[1]:cut_rect[3],cut_rect[0]:cut_rect[2]]

                if self.originFrame is not None:
                    renderImg = cv2.cvtColor(self.originFrame, cv2.COLOR_BGR2RGB)
                    # 모두 인식하면 최종 걸린시간 계산
                    bFishedAllObjDetection = True
                    for dateTime in self.picDateTime:
                        if dateTime is None:
                            bFishedAllObjDetection = False
                            break
                        
                    if self.timerStartTime != None:
                        timerDateTime = datetime.datetime.now() - self.timerStartTime
                        allSec = timerDateTime.seconds
                        allSec = float(allSec%3600)+(timerDateTime.microseconds/10000000)
                        self.mtime.display('%.2f'%allSec)

                        # 추론결과물 받기
                        infer_time, classifiedLabel = self.objDetector.getProcessedData()
                        if len(classifiedLabel) > 0 and classifiedLabel[0][1] >= self.CLASSIFICATION_CONF:
                            if self.prevFrameLabelIdx == -1 or self.prevFrameLabelIdx != classifiedLabel[0][0]:
                                self.prevFrameLabelIdx = classifiedLabel[0][0]
                                self.sameDetectionFrameCount = 1
                            elif self.prevFrameLabelIdx == classifiedLabel[0][0]:
                                self.sameDetectionFrameCount += 1
                        else:
                            self.prevFrameLabelIdx = -1
                            self.sameDetectionFrameCount = 0

                        # detected
                        if self.sameDetectionFrameCount >= self.CLASSIFICATION_FRAME:
                            detectedLabel = self.objDetector.labels[classifiedLabel[0][0]]
                            for i in range(len(self.txtLabels)):
                                if self.latestDetectedLabel != self.txtLabels[i] and detectedLabel == self.txtLabels[i] and len(classifiedLabel) > 0 and classifiedLabel[0][1] >= self.probs[i]:
                                    #현재시간
                                    curTime = datetime.datetime.now()
                                    timerDateTime = curTime - self.timerStartTime
                                    allSec = float(allSec%3600)+(timerDateTime.microseconds/10000000)
                                    
                                    self.picTimes[i].setText('%.2f Sec.' % allSec)
                                    self.picDateTime[i] = curTime

                                    # 이미지 업데이트
                                    objRenderImg = cv2.resize(self.originFrame, (picRenderW, picRenderH))
                                    objRenderImg = cv2.cvtColor(objRenderImg, cv2.COLOR_BGR2RGB)
                                    bytesPerLine = 3 * picRenderW
                                    qImg = QImage(objRenderImg.data, picRenderW, picRenderH,
                                                bytesPerLine, QImage.Format_RGB888)
                                    self.pics[i].setPixmap(QPixmap(qImg))
                                    # 다음 인식할 준비
                                    self.latestDetectedLabel = detectedLabel
                                    # 이미지 저장
                                    onlyObjFrameBGR = cv2.cvtColor(objRenderImg, cv2.COLOR_RGB2BGR)
                                    cv2.imwrite('./result/' + self.latestDetectedLabel + curTime.__str__()+ '.jpg', onlyObjFrameBGR)
                                    
                                    self.probs[i] = classifiedLabel[0][1]
                                    self.picProbs[i].setText('%0.2f %%' % classifiedLabel[0][1])
                                    
                                    tprob = 0
                                    for j in range(8):
                                        tprob += self.probs[j]
                                    tprob = tprob/8.0
                                    self.avgRate.setText('%.2f %%' % tprob)
                                    
                            if len(classifiedLabel) > 0:
                                # 각 레이블의 conf값 보여주기
                                for i in range(3):
                                    if i >= 3:
                                        break
                                    labelIdx = classifiedLabel[i][0]
                                    conf = classifiedLabel[i][1]
                                    cv2.putText(renderImg, '%-15s' % self.objDetector.labels[labelIdx] + ' %.2f' % conf, (15, 60 + 45*i ),
                                    cv2.FONT_HERSHEY_COMPLEX, 1.5, (10, 10, 200), 2)
                        
                        inf_time_message = "Inference time: {:.3f} ms".format(infer_time * 1000)
                        cv2.putText(renderImg, inf_time_message, (15, 15), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                                    (200, 10, 10), 1)
                        
                    #QtLabel에 뿌리기
                    cv2.rectangle(renderImg,(cut_rect[0],cut_rect[1]),(cut_rect[2],cut_rect[3]),(0,255,0),2)
                    renderImg = cv2.resize(renderImg, (renderingW, renderingH))

                    bytesPerLine = 3 * renderingW
                    qImg = QImage(renderImg.data, renderingW, renderingH, bytesPerLine, QImage.Format_RGB888)
                    self.video.setPixmap(QPixmap(qImg))

        except Exception as error:
            traceback.print_exc()
            #print("catch error")
            
    def createCategoryControl(self, page: SARibbonCategory):
        pannel = page.addPannel('Main')
        # act 1
        self.conBtn = QAction(self)
        self.conBtn.setObjectName('Connect')
        self.conBtn.setText('연결')
        self.conBtn.setToolTip('Connect')
        self.conBtn.setIcon(QIcon('res/icon/connect.png'))
        self.conBtn.setShortcut(QKeySequence('Ctrl+C'))
        pannel.addLargeAction(self.conBtn)
        self.conBtn.triggered.connect(self.Connect)
        # act 2
        self.takeoffBtn = QAction(self)
        self.takeoffBtn.setObjectName('Takeoff')
        self.takeoffBtn.setText('이륙')
        self.takeoffBtn.setIcon(QIcon('res/icon/takeoff.png'))
        #act.setCheckable(True)
        self.takeoffBtn.setShortcut(QKeySequence('Ctrl+T'))
        pannel.addLargeAction(self.takeoffBtn)
        self.takeoffBtn.triggered.connect(self.onTakeoffButtontriggered)
        # act 3
        self.landBtn = QAction(self)
        self.landBtn.setObjectName('Land')
        self.landBtn.setText('착륙')
        self.landBtn.setIcon(QIcon('res/icon/land.png'))
        #act.setCheckable(True)
        self.landBtn.setEnabled(False)
        self.landBtn.setShortcut(QKeySequence('Ctrl+L'))
        pannel.addLargeAction(self.landBtn)
        self.landBtn.triggered.connect(self.onLandButtontriggered)
        #act.trigger()

        pannel2 = page.addPannel('Control')

        act = QAction(self)
        act.setObjectName('Up')
        act.setText('상승')
        act.setIcon(QIcon('res/icon/up.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('W'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onUpButtontriggered)
        #btn = pannel2.addLargeAction(act)
        #btn.setCheckable(True)

        act = QAction(self)
        act.setObjectName('Down')
        act.setText('하강')
        act.setIcon(QIcon('res/icon/down.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('S'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onDownButtontriggered)

        pannel2.addSeparator()
        
        act = QAction(self)
        act.setObjectName('Rotate')
        act.setText('정회전')
        act.setIcon(QIcon('res/icon/clockwise.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('D'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onCWButtontriggered)
        
        act = QAction(self)
        act.setObjectName('Reverse')
        act.setText('역회전')
        act.setIcon(QIcon('res/icon/counterclock.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('A'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onCCWButtontriggered)

        pannel2.addSeparator()
        
        act = QAction(self)
        act.setObjectName('East')
        act.setText('동')
        act.setIcon(QIcon('res/icon/east.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('Left'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onEastButtontriggered)
        #btn = pannel2.addLargeAction(act)
        #btn.setCheckable(True)

        act = QAction(self)
        act.setObjectName('West')
        act.setText('서')
        act.setIcon(QIcon('res/icon/west.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('Right'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onWestButtontriggered)
        
        act = QAction(self)
        act.setObjectName('South')
        act.setText('남')
        act.setIcon(QIcon('res/icon/south.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('Down'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onSouthButtontriggered)
        
        act = QAction(self)
        act.setObjectName('North')
        act.setText('북')
        act.setIcon(QIcon('res/icon/north.png'))
        #act.setCheckable(True)
        act.setShortcut(QKeySequence('Up'))
        pannel2.addLargeAction(act)
        act.triggered.connect(self.onNorthButtontriggered)

        pannel2.addSeparator()        
        #pannel2.setExpanding()
        pannel2.setVisible(True)

    def createCategorySetting(self, page: SARibbonCategory):
        pannel = SARibbonPannel('Information')
        page.addPannel(pannel)

        label = QLabel("My IP");
        self.m_ipEdit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.m_ipEdit.setWindowTitle("My IP")
        self.m_ipEdit.setText("192.168.10.2")
        self.m_ip = "192.168.10.2"
        self.m_ipEdit.textChanged.connect(self.onIPChanged)
        
        pannel.addLargeWidget(label)
        pannel.addLargeWidget(self.m_ipEdit)
        
        label = QLabel("Step");        
        self.m_stepEdit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.m_stepEdit.setWindowTitle("Step")
        self.m_stepEdit.setText("20")
        self.m_step = "20"
        self.m_stepEdit.textChanged.connect(self.onStepChanged)
        pannel.addLargeWidget(label)
        pannel.addLargeWidget(self.m_stepEdit)
        
    def Connect(self):
        if self.tello.tryConnect():
            self.conBtn.setObjectName('DisConnect')
            self.conBtn.setText('해제')
            self.conBtn.setToolTip('DisConnect')
            self.conBtn.triggered.connect(self.Disconnect)
        else:
            self.log("연결실패")
            
    def Disconnect(self):
        #self.resetDetectionInfo()
        self.tello.disconnect()
        self.conBtn.setObjectName('Connect')
        self.conBtn.setText('연결')
        self.conBtn.setToolTip('Connect')
        self.conBtn.triggered.connect(self.Connect)
        self.video.setPixmap(QPixmap("./res/logo.png"))

    def onTakeoffButtontriggered(self):
        if self.timerStartTime is None:
            self.timerStartTime = datetime.datetime.now()
        if self.tello.socket is None:
            self.log("tello is not connected.")
            return
        cmd = "takeoff"
        self.log(cmd)
        self.tello.send_command(cmd)
        self.takeoffBtn.setEnabled(False)
        self.landBtn.setEnabled(True)

    def onLandButtontriggered(self):
        if self.tello.socket is None:
            #self.log("tello is not connected.")
            return
        cmd = "land"
        #self.log(cmd)
        self.tello.send_command(cmd)
        #self.resetDetectionInfo()
        
        curTime = datetime.datetime.now()
        timerDateTime = curTime - self.timerStartTime
        allSec = timerDateTime.seconds
        allSec = float(allSec%3600)+(timerDateTime.microseconds/10000000)
        self.totalTime.setText('%.2f Sec.' % allSec)
        
        self.takeoffBtn.setEnabled(True)
        self.landBtn.setEnabled(False)

    def onUpButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "up "+self.m_step
        self.tello.send_command(cmd)

    def onDownButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "down "+self.m_step
        self.tello.send_command(cmd)

    def onCWButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "cw "+self.m_step
        self.tello.send_command(cmd)

    def onCCWButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "ccw "+self.m_step
        self.tello.send_command(cmd)

    def onNorthButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "forward "+self.m_step
        self.tello.send_command(cmd)

    def onSouthButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "backward "+self.m_step
        self.tello.send_command(cmd)

    def onEastButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "left "+self.m_step
        self.tello.send_command(cmd)

    def onWestButtontriggered(self):
        if self.tello.socket is None: return
        cmd = "right "+self.m_step
        self.tello.send_command(cmd)
        
    def onIPChanged(self):
        self.m_ip = self.m_ipEdit.text()
        self.tello.local_main_ip = self.m_ip

    def onStepChanged(self):
        self.m_step = self.m_stepEdit.text()
        
if __name__ == '__main__':
    try:
        if not os.path.exists('./result'):
            os.makedirs('./result')
    except Exception as err:
        print('result 디렉토리 확인중에 문제가 발생했습니다.')
        print(err.__str__())
        
    app = QApplication(sys.argv)
    # 설정
    font = app.font()
    font.setFamily('맑은고딕')
    app.setFont(font)

    mainWindow = MainWindow()
    mainWindow.show()
    a = app.exec()
    if mainWindow.tello.cap is not None:
        mainWindow.tello.cap.release()
        
    sys.exit(a)
