# -*- coding: utf-8 -*-
"""
@Module     SARibbonControlButton
@Author     ROOT
"""
from PyQt5.QtWidgets import QToolButton


class SARibbonControlButton(QToolButton):
    def __init__(self, parent):
        super().__init__(parent)
